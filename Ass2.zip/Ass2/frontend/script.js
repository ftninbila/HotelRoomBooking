const apiBaseUrl = 'http://localhost:5000/api';

// Login functionality
document.getElementById('login-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const email = document.getElementById('email').value;
  const password = document.getElementById('password').value;

  try {
    const response = await fetch(`${apiBaseUrl}/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password }),
    });
    const data = await response.json();
    if (response.ok) {
      alert('Login successful!');
      localStorage.setItem('token', data.token);
      loadRooms();
    } else {
      alert(data.message);
    }
  } catch (error) {
    console.error('Error logging in:', error);
  }
});

// Load rooms
async function loadRooms() {
  const roomsDiv = document.getElementById('rooms');
  roomsDiv.innerHTML = '';
  try {
    const response = await fetch(`${apiBaseUrl}/rooms`);
    const rooms = await response.json();
    rooms.forEach((room) => {
      const roomDiv = document.createElement('div');
      roomDiv.className = 'room';
      roomDiv.innerHTML = `
        <p>Type: ${room.type}</p>
        <p>Price: $${room.price}</p>
        <p>Amenities: ${room.amenities.join(', ')}</p>
        <p>Available: ${room.availability ? 'Yes' : 'No'}</p>
        <button onclick="selectRoom('${room._id}')">Select</button>
      `;
      roomsDiv.appendChild(roomDiv);
    });
  } catch (error) {
    console.error('Error loading rooms:', error);
  }
}

function selectRoom(roomId) {
  document.getElementById('room-id').value = roomId;
}

// Make a reservation
document.getElementById('reservation-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const token = localStorage.getItem('token');
  if (!token) return alert('Please login first.');

  const room_id = document.getElementById('room-id').value;
  const check_in = document.getElementById('check-in').value;
  const check_out = document.getElementById('check-out').value;
  const guests = document.getElementById('guests').value;

  try {
    const response = await fetch(`${apiBaseUrl}/reservations`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({ room_id, check_in, check_out, guests }),
    });
    const data = await response.json();
    if (response.ok) {
      alert('Reservation successful!');
      loadRooms();
    } else {
      alert(data.error);
    }
  } catch (error) {
    console.error('Error making reservation:', error);
  }
});
